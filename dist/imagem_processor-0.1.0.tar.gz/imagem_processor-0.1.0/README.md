# Imagem Processor

Pacote Python para processamento de imagens, com funcionalidades como redimensionamento, filtro de desfoque e conversão para escala de cinza.
